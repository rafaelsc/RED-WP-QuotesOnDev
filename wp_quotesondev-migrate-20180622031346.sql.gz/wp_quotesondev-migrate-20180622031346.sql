# WordPress MySQL database migration
#
# Generated: Friday 22. June 2018 03:13 UTC
# Hostname: localhost
# Database: `wp_quotesondev`
# URL: //localhost:8088/quotesondev
# Path: /Applications/MAMP/htdocs/student
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-05-24 03:34:55', '2018-05-24 03:34:55', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8088/quotesondev', 'yes'),
(2, 'home', 'http://localhost:8088/quotesondev', 'yes'),
(3, 'blogname', 'Quotes On Dev', 'yes'),
(4, 'blogdescription', 'Some great quotes about programmers and languages', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mail@mail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:86:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:11:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:19:"akismet/akismet.php";i:2;s:74:"debug-bar-actions-and-filters-addon/debug-bar-action-and-filters-addon.php";i:3;s:41:"debug-bar-rewrite-rules/rewrite-rules.php";i:4;s:49:"debug-bar-slow-actions/debug-bar-slow-actions.php";i:5;s:23:"debug-bar/debug-bar.php";i:6;s:9:"hello.php";i:7;s:27:"theme-check/theme-check.php";i:8;s:41:"wordpress-importer/wordpress-importer.php";i:9;s:31:"wp-log-viewer/wp-log-viewer.php";i:10;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'quotesondev', 'yes'),
(41, 'stylesheet', 'quotesondev', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:41:"debug-bar-rewrite-rules/rewrite-rules.php";s:17:"umdbrr_deactivate";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '207', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'initial_db_version', '38590', 'yes'),
(93, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(94, 'fresh_site', '0', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'cron', 'a:3:{i:1529638496;a:4:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1529638513;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(111, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1527134033;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(126, 'can_compress_scripts', '0', 'no'),
(143, 'recently_activated', 'a:0:{}', 'yes'),
(144, 'category_children', 'a:0:{}', 'yes'),
(147, 'current_theme', 'Quotes on Dev Starter Theme', 'yes'),
(148, 'theme_mods_quotesondev', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(149, 'theme_switched', '', 'yes'),
(181, 'debug_bar_rewrite_rules_filters_list', 'a:3:{s:4:"list";a:11:{i:0;s:22:"category_rewrite_rules";i:1;s:25:"post_format_rewrite_rules";i:2;s:18:"post_rewrite_rules";i:3;s:18:"date_rewrite_rules";i:4;s:18:"root_rewrite_rules";i:5;s:22:"comments_rewrite_rules";i:6;s:20:"search_rewrite_rules";i:7;s:20:"author_rewrite_rules";i:8;s:18:"page_rewrite_rules";i:9;s:17:"tag_rewrite_rules";i:10;s:19:"rewrite_rules_array";}s:5:"count";i:10;s:7:"details";a:10:{s:22:"category_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:25:"post_format_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"post_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"date_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"root_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:22:"comments_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:20:"search_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:20:"author_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:18:"page_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}s:17:"tag_rewrite_rules";a:1:{i:9000;a:1:{i:0;a:2:{i:0;s:7:"dynamic";i:1;s:36:"$Debug_Bar_Slow_Actions->time_stop()";}}}}}', 'yes'),
(182, 'debug_bar_rewrite_rules_installed', '1', 'yes'),
(183, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(339, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1529637226;}', 'no'),
(362, 'core_updater.lock', '1529636774', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 19, '_edit_last', '1'),
(6, 21, '_edit_last', '1'),
(7, 21, '_qod_quote_source', 'The Structure and Interpretation of Computer Programs'),
(8, 23, '_edit_last', '1'),
(9, 25, '_edit_last', '1'),
(10, 27, '_edit_last', '1'),
(11, 29, '_edit_last', '1'),
(12, 31, '_edit_last', '1'),
(13, 33, '_edit_last', '1'),
(14, 33, '_qod_quote_source', 'Program or Be Programmed: Ten Commands for a Digital Age'),
(15, 35, '_edit_last', '1'),
(16, 37, '_edit_last', '1'),
(17, 37, '_qod_quote_source', 'Code Simplicity: The Fundamentals of Software'),
(18, 39, '_edit_last', '1'),
(19, 41, '_edit_last', '1'),
(20, 43, '_edit_last', '1'),
(21, 107, '_edit_last', '1'),
(22, 111, '_edit_last', '1'),
(23, 113, '_edit_last', '1'),
(24, 114, '_menu_item_type', 'post_type'),
(25, 114, '_menu_item_menu_item_parent', '0'),
(26, 114, '_menu_item_object_id', '107'),
(27, 114, '_menu_item_object', 'page'),
(28, 114, '_menu_item_target', ''),
(29, 114, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(30, 114, '_menu_item_xfn', ''),
(31, 114, '_menu_item_url', ''),
(32, 115, '_menu_item_type', 'post_type'),
(33, 115, '_menu_item_menu_item_parent', '0'),
(34, 115, '_menu_item_object_id', '113'),
(35, 115, '_menu_item_object', 'page'),
(36, 115, '_menu_item_target', ''),
(37, 115, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(38, 115, '_menu_item_xfn', ''),
(39, 115, '_menu_item_url', ''),
(40, 116, '_menu_item_type', 'post_type'),
(41, 116, '_menu_item_menu_item_parent', '0'),
(42, 116, '_menu_item_object_id', '111'),
(43, 116, '_menu_item_object', 'page'),
(44, 116, '_menu_item_target', ''),
(45, 116, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(46, 116, '_menu_item_xfn', ''),
(47, 116, '_menu_item_url', ''),
(48, 45, '_edit_last', '1'),
(49, 47, '_edit_last', '1'),
(50, 49, '_edit_last', '1'),
(51, 51, '_edit_last', '1'),
(52, 51, '_qod_quote_source', 'Game Programming Patterns'),
(53, 53, '_edit_last', '1'),
(54, 53, '_qod_quote_source', 'Game Programming Patterns'),
(55, 55, '_edit_last', '1'),
(56, 55, '_qod_quote_source', 'Clean Code: A Handbook of Agile Software Craftsmanship'),
(57, 57, '_edit_last', '1'),
(58, 57, '_qod_quote_source', 'Working Effectively with Legacy Code'),
(59, 59, '_edit_last', '1'),
(60, 61, '_edit_last', '1'),
(61, 63, '_edit_last', '1'),
(62, 65, '_edit_last', '1'),
(63, 67, '_edit_last', '1'),
(64, 69, '_edit_last', '1'),
(65, 71, '_edit_last', '1'),
(66, 73, '_edit_last', '1'),
(67, 75, '_edit_last', '1'),
(68, 77, '_edit_last', '1'),
(69, 79, '_edit_last', '1'),
(70, 79, '_qod_quote_source', 'The Mythical Man-Month'),
(71, 81, '_edit_last', '1'),
(72, 83, '_edit_last', '1'),
(73, 85, '_edit_last', '1'),
(74, 87, '_edit_last', '1'),
(75, 89, '_edit_last', '1'),
(76, 89, '_qod_quote_source', 'christianheilmann.com'),
(77, 89, '_qod_quote_source_url', 'https://www.christianheilmann.com/2005/11/08/do-hr-people-even-read-their-job-ads-when-they-get-published/'),
(78, 91, '_edit_last', '1'),
(79, 91, '_qod_quote_source', 'What Is Code?'),
(80, 91, '_qod_quote_source_url', 'http://www.bloomberg.com/graphics/2015-paul-ford-what-is-code/'),
(81, 93, '_edit_last', '1'),
(82, 95, '_edit_last', '1'),
(83, 97, '_edit_last', '1'),
(84, 101, '_edit_last', '1'),
(85, 101, '_qod_quote_source', 'The Art of Web Design'),
(86, 101, '_qod_quote_source_url', 'https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CDkQtwIwAGoVChMI1uS97rLuyAIVVfFjCh3DFwrM&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D3iVVM_DgWY4&usg=AFQjCNGKP6BAccnj6iPxgUB_UhEsW-A5xg'),
(87, 103, '_edit_last', '1'),
(88, 103, '_qod_quote_source', 'gerrymcgovern.com'),
(89, 103, '_qod_quote_source_url', 'http://www.gerrymcgovern.com/new-thinking/why-do-organizations-hate-their-content-management-system'),
(90, 105, '_edit_last', '1'),
(91, 105, '_qod_quote_source', 'Medium'),
(92, 105, '_qod_quote_source_url', 'https://medium.com/javascript-scene/the-two-pillars-of-javascript-ee6f3281e7f3'),
(93, 159, '_edit_last', '1'),
(94, 161, '_edit_last', '1'),
(95, 161, '_qod_quote_source', '@sanityinc'),
(96, 161, '_qod_quote_source_url', 'https://twitter.com/sanityinc'),
(97, 163, '_edit_last', '1'),
(98, 163, '_qod_quote_source', '@iamdevloper'),
(99, 163, '_qod_quote_source_url', 'https://twitter.com/iamdevloper'),
(100, 165, '_edit_last', '1'),
(101, 165, '_qod_quote_source', '@garybernhardt'),
(102, 165, '_qod_quote_source_url', 'https://twitter.com/garybernhardt') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(103, 169, '_edit_last', '1'),
(104, 169, '_qod_quote_source', '@tomscott'),
(105, 169, '_qod_quote_source_url', 'https://twitter.com/tomscott'),
(106, 171, '_edit_last', '1'),
(107, 171, '_qod_quote_source', '@d6'),
(108, 171, '_qod_quote_source_url', 'https://twitter.com/d6'),
(109, 173, '_edit_last', '1'),
(110, 173, '_qod_quote_source', '@JaesCoyle'),
(111, 173, '_qod_quote_source_url', 'https://twitter.com/JaesCoyle'),
(112, 175, '_edit_last', '1'),
(113, 175, '_qod_quote_source', '@nedbat'),
(114, 175, '_qod_quote_source_url', 'https://twitter.com/nedbat'),
(115, 177, '_edit_last', '1'),
(116, 177, '_qod_quote_source', '@fortes'),
(117, 177, '_qod_quote_source_url', 'https://twitter.com/fortes'),
(118, 179, '_edit_last', '1'),
(119, 179, '_qod_quote_source', '@mhoye'),
(120, 179, '_qod_quote_source_url', 'https://twitter.com/mhoye'),
(121, 181, '_edit_last', '1'),
(122, 204, '_edit_last', '1'),
(123, 204, '_qod_quote_source', '@jamesshore'),
(124, 204, '_qod_quote_source_url', 'https://twitter.com/jamesshore'),
(125, 205, '_edit_lock', '1527215737:1'),
(126, 206, '_wp_attached_file', '2018/05/quot.png'),
(127, 206, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:64;s:6:"height";i:64;s:4:"file";s:16:"2018/05/quot.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(128, 207, '_wp_attached_file', '2018/05/cropped-quot.png'),
(129, 207, '_wp_attachment_context', 'site-icon'),
(130, 207, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:24:"2018/05/cropped-quot.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"cropped-quot-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"cropped-quot-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-270";a:4:{s:4:"file";s:24:"cropped-quot-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-192";a:4:{s:4:"file";s:24:"cropped-quot-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-180";a:4:{s:4:"file";s:24:"cropped-quot-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:22:"cropped-quot-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(131, 205, '_wp_trash_meta_status', 'publish'),
(132, 205, '_wp_trash_meta_time', '1527215787'),
(134, 208, '_wp_trash_meta_status', 'publish'),
(135, 208, '_wp_trash_meta_time', '1527215853'),
(136, 169, '_edit_lock', '1527215768:1'),
(137, 107, '_edit_lock', '1527822967:1'),
(138, 113, '_edit_lock', '1527817412:1'),
(139, 2, '_edit_lock', '1527215798:1'),
(140, 111, '_edit_lock', '1527643399:1'),
(141, 2, '_wp_trash_meta_status', 'publish'),
(142, 2, '_wp_trash_meta_time', '1527645332'),
(143, 2, '_wp_desired_post_slug', 'sample-page'),
(144, 1, '_wp_trash_meta_status', 'publish'),
(145, 1, '_wp_trash_meta_time', '1527648247'),
(146, 1, '_wp_desired_post_slug', 'hello-world'),
(147, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(148, 179, '_edit_lock', '1527648751:1'),
(150, 212, '_edit_lock', '1527821100:1'),
(151, 212, '_wp_trash_meta_status', 'publish'),
(152, 212, '_wp_trash_meta_time', '1527821247'),
(153, 212, '_wp_desired_post_slug', 'rafaelsc'),
(155, 214, '_qod_quote_source', 'ontheline'),
(156, 214, '_qod_quote_source_url', 'https://www.youtube.com/watch?v=9F9ahZQ7oP0'),
(157, 214, '_edit_lock', '1527821416:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-05-24 03:34:55', '2018-05-24 03:34:55', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-05-30 02:44:07', '2018-05-30 02:44:07', '', 0, 'http://localhost:8088/quotesondev/?p=1', 0, 'post', '', 1),
(2, 1, '2018-05-24 03:34:55', '2018-05-24 03:34:55', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost:8088/quotesondev/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2018-05-30 01:55:32', '2018-05-30 01:55:32', '', 0, 'http://localhost:8088/quotesondev/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-05-24 03:34:55', '2018-05-24 03:34:55', '<h2>Who we are</h2><p>Our website address is: http://localhost:8088/quotesondev.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracing your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2018-05-24 03:34:55', '2018-05-24 03:34:55', '', 0, 'http://localhost:8088/quotesondev/?page_id=3', 0, 'page', '', 0),
(4, 1, '2018-05-24 03:35:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-05-24 03:35:14', '0000-00-00 00:00:00', '', 0, 'http://localhost:8088/quotesondev/?p=4', 0, 'post', '', 0),
(19, 1, '2015-10-30 23:13:59', '2015-10-30 23:13:59', 'Talk is cheap. Show me the code.', 'Linus Torvalds', '', 'publish', 'open', 'open', '', 'linus-torvalds', '', '', '2015-10-30 23:13:59', '2015-10-30 23:13:59', '', 0, 'http://quotes.academy.red/?p=19', 0, 'post', '', 0),
(21, 1, '2015-10-30 23:35:43', '2015-10-30 23:35:43', 'Programs must be written for people to read, and only incidentally for machines to execute.', 'Harold Abelson', '', 'publish', 'open', 'open', '', 'harold-abelson', '', '', '2015-10-30 23:35:43', '2015-10-30 23:35:43', '', 0, 'http://quotes.academy.red/?p=21', 0, 'post', '', 0),
(23, 1, '2015-10-30 23:36:35', '2015-10-30 23:36:35', 'Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live.', 'John Woods', '', 'publish', 'open', 'open', '', 'john-woods', '', '', '2015-10-30 23:36:35', '2015-10-30 23:36:35', '', 0, 'http://quotes.academy.red/?p=23', 0, 'post', '', 0),
(25, 1, '2015-10-30 23:40:03', '2015-10-30 23:40:03', 'Give a man a program, frustrate him for a day. Teach a man to program, frustrate him for a lifetime.', 'Waseem Latif', '', 'publish', 'open', 'open', '', 'waseem-latif', '', '', '2015-10-30 23:40:03', '2015-10-30 23:40:03', '', 0, 'http://quotes.academy.red/?p=25', 0, 'post', '', 0),
(27, 1, '2015-10-31 20:25:18', '2015-10-31 20:25:18', 'Perl – The only language that looks the same before and after RSA encryption.', 'Keith Bostic', '', 'publish', 'open', 'open', '', 'keith-bostic', '', '', '2015-10-31 20:25:18', '2015-10-31 20:25:18', '', 0, 'http://quotes.academy.red/?p=27', 0, 'post', '', 0),
(29, 1, '2015-10-31 20:26:50', '2015-10-31 20:26:50', 'Walking on water and developing software from a specification are easy if both are frozen.', 'Edward Berard', '', 'publish', 'open', 'open', '', 'edward-berard', '', '', '2015-10-31 20:26:50', '2015-10-31 20:26:50', '', 0, 'http://quotes.academy.red/?p=29', 0, 'post', '', 0),
(31, 1, '2015-10-31 20:27:03', '2015-10-31 20:27:03', 'The most important property of a program is whether it accomplishes the intention of its user.', 'C.A.R. Hoare', '', 'publish', 'open', 'open', '', 'c-a-r-hoare', '', '', '2015-10-31 20:27:03', '2015-10-31 20:27:03', '', 0, 'http://quotes.academy.red/?p=31', 0, 'post', '', 0),
(33, 1, '2015-10-31 20:27:54', '2015-10-31 20:27:54', 'We are looking at a society increasingly dependent on machines, yet decreasingly capable of making or even using them effectively.', 'Douglas Rushkoff', '', 'publish', 'open', 'open', '', 'douglas-rushkoff', '', '', '2015-10-31 20:27:54', '2015-10-31 20:27:54', '', 0, 'http://quotes.academy.red/?p=33', 0, 'post', '', 0),
(35, 1, '2015-10-31 20:28:34', '2015-10-31 20:28:34', 'I\'m not a great programmer; I\'m just a good programmer with great habits.', 'Kent Beck', '', 'publish', 'open', 'open', '', 'kent-beck', '', '', '2015-10-31 20:28:34', '2015-10-31 20:28:34', '', 0, 'http://quotes.academy.red/?p=35', 0, 'post', '', 0),
(37, 1, '2015-10-31 20:29:52', '2015-10-31 20:29:52', 'Some of the best programming is done on paper, really. Putting it into the computer is just a minor detail.', 'Max Kanat-Alexander', '', 'publish', 'open', 'open', '', 'max-kanat-alexander', '', '', '2015-10-31 20:29:52', '2015-10-31 20:29:52', '', 0, 'http://quotes.academy.red/?p=37', 0, 'post', '', 0),
(39, 1, '2015-10-31 20:30:38', '2015-10-31 20:30:38', 'Any fool can write code that a computer can understand. Good programmers write code that humans can understand.', 'Martin Fowler', '', 'publish', 'open', 'open', '', 'martin-fowler', '', '', '2015-10-31 20:30:38', '2015-10-31 20:30:38', '', 0, 'http://quotes.academy.red/?p=39', 0, 'post', '', 0),
(41, 1, '2015-10-31 20:32:56', '2015-10-31 20:32:56', 'Simplicity is prerequisite for reliability.', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra', '', '', '2015-10-31 20:32:56', '2015-10-31 20:32:56', '', 0, 'http://quotes.academy.red/?p=41', 0, 'post', '', 0),
(43, 1, '2015-10-31 20:33:49', '2015-10-31 20:33:49', 'The Analytical Engine weaves algebraic patterns, just as the Jacquard loom weaves flowers and leaves.', 'Ada Lovelace', '', 'publish', 'open', 'open', '', 'ada-lovelace', '', '', '2015-10-31 20:33:49', '2015-10-31 20:33:49', '', 0, 'http://quotes.academy.red/?p=43', 0, 'post', '', 0),
(45, 1, '2015-10-31 20:34:48', '2015-10-31 20:34:48', 'Sometimes it pays to stay in bed on Monday, rather than spending the rest of the week debugging Monday\'s code', 'Dan Salomon', '', 'publish', 'open', 'open', '', 'dan-salomon', '', '', '2015-10-31 20:34:48', '2015-10-31 20:34:48', '', 0, 'http://quotes.academy.red/?p=45', 0, 'post', '', 0),
(47, 1, '2015-10-31 20:35:52', '2015-10-31 20:35:52', 'It goes against the grain of modern education to teach children to program. What fun is there in making plans, acquiring discipline in organizing thoughts, devoting attention to detail and learning to be self-critical?', 'Alan J. Perlis', '', 'publish', 'open', 'open', '', 'alan-j-perlis', '', '', '2015-10-31 20:35:52', '2015-10-31 20:35:52', '', 0, 'http://quotes.academy.red/?p=47', 0, 'post', '', 0),
(49, 1, '2015-10-31 20:36:12', '2015-10-31 20:36:12', 'Kids who are good at traditional school—repeating rote concepts and facts on a test—can fall apart in a situation where that isn’t enough. Programming rewards the experimental, curious mind.', 'Ketil Moland Olsen', '', 'publish', 'open', 'open', '', 'ketil-moland-olsen', '', '', '2015-10-31 20:36:12', '2015-10-31 20:36:12', '', 0, 'http://quotes.academy.red/?p=49', 0, 'post', '', 0),
(51, 1, '2015-10-31 20:37:22', '2015-10-31 20:37:22', 'Like so many things in software, MVC was invented by Smalltalkers in the seventies. Lispers probably claim they came up with it in the sixties but didn\'t bother writing it down.', 'Robert Nystrom', '', 'publish', 'open', 'open', '', 'robert-nystrom', '', '', '2015-10-31 20:37:22', '2015-10-31 20:37:22', '', 0, 'http://quotes.academy.red/?p=51', 0, 'post', '', 0),
(53, 1, '2015-10-31 20:38:02', '2015-10-31 20:38:02', 'Most non-programmers don\'t think of plaintext like that. To them, text files feel like filling in tax forms for an angry robotic auditor that yells at them if they forget a single semicolon.', 'Robert Nystrom', '', 'publish', 'open', 'open', '', 'robert-nystrom-2', '', '', '2015-10-31 20:38:02', '2015-10-31 20:38:02', '', 0, 'http://quotes.academy.red/?p=53', 0, 'post', '', 0),
(55, 1, '2015-10-31 20:39:09', '2015-10-31 20:39:09', 'Truth can only be found in one place: the code.', 'Robert C. Martin', '', 'publish', 'open', 'open', '', 'robert-c-martin', '', '', '2015-10-31 20:39:09', '2015-10-31 20:39:09', '', 0, 'http://quotes.academy.red/?p=55', 0, 'post', '', 0),
(57, 1, '2015-10-31 20:39:46', '2015-10-31 20:39:46', 'Programming is the art of doing one thing at a time.', 'Michael C. Feathers', '', 'publish', 'open', 'open', '', 'michael-c-feathers', '', '', '2015-10-31 20:39:46', '2015-10-31 20:39:46', '', 0, 'http://quotes.academy.red/?p=57', 0, 'post', '', 0),
(59, 1, '2015-10-31 20:57:19', '2015-10-31 20:57:19', 'I love deadlines. I like the whooshing sound they make as they go by.', 'Douglas Adams', '', 'publish', 'open', 'open', '', 'douglas-adams', '', '', '2015-10-31 20:57:19', '2015-10-31 20:57:19', '', 0, 'http://quotes.academy.red/?p=59', 0, 'post', '', 0),
(61, 1, '2015-10-31 20:57:57', '2015-10-31 20:57:57', 'If debugging is the process of removing software bugs, then programming must be the process of putting them in.', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra-2', '', '', '2015-10-31 20:57:57', '2015-10-31 20:57:57', '', 0, 'http://quotes.academy.red/?p=61', 0, 'post', '', 0),
(63, 1, '2015-10-31 20:58:40', '2015-10-31 20:58:40', 'There are two ways of constructing a software design: One way is to make it so simple that there are obviously no deficiencies, and the other way is to make it so complicated that there are no obvious deficiencies. The first method is far more difficult.', 'C.A.R. Hoare', '', 'publish', 'open', 'open', '', 'c-a-r-hoare-2', '', '', '2015-10-31 20:58:40', '2015-10-31 20:58:40', '', 0, 'http://quotes.academy.red/?p=63', 0, 'post', '', 0),
(65, 1, '2015-10-31 20:59:24', '2015-10-31 20:59:24', 'Measuring programming progress by lines of code is like measuring aircraft building progress by weight.', 'Bill Gates', '', 'publish', 'open', 'open', '', 'bill-gates', '', '', '2015-10-31 20:59:24', '2015-10-31 20:59:24', '', 0, 'http://quotes.academy.red/?p=65', 0, 'post', '', 0),
(67, 1, '2015-10-31 21:00:01', '2015-10-31 21:00:01', 'Most good programmers do programming not because they expect to get paid or get adulation by the public, but because it is fun to program.', 'Linus Torvalds', '', 'publish', 'open', 'open', '', 'linus-torvalds-2', '', '', '2015-10-31 21:00:01', '2015-10-31 21:00:01', '', 0, 'http://quotes.academy.red/?p=67', 0, 'post', '', 0),
(69, 1, '2015-10-31 21:00:54', '2015-10-31 21:00:54', 'People think that computer science is the art of geniuses but the actual reality is the opposite, just many people doing things that build on each other, like a wall of mini stones.', 'Donald Knuth', '', 'publish', 'open', 'open', '', 'donald-knuth', '', '', '2015-10-31 21:00:54', '2015-10-31 21:00:54', '', 0, 'http://quotes.academy.red/?p=69', 0, 'post', '', 0),
(71, 1, '2015-10-31 21:01:52', '2015-10-31 21:01:52', 'One of my most productive days was throwing away 1000 lines of code.', 'Ken Thompson', '', 'publish', 'open', 'open', '', 'ken-thompson', '', '', '2015-10-31 21:01:52', '2015-10-31 21:01:52', '', 0, 'http://quotes.academy.red/?p=71', 0, 'post', '', 0),
(73, 1, '2015-10-31 21:02:24', '2015-10-31 21:02:24', 'If builders built buildings the way programmers wrote programs, then the first woodpecker that came along wound destroy civilization.', 'Gerald Weinberg', '', 'publish', 'open', 'open', '', 'gerald-weinberg', '', '', '2015-10-31 21:02:24', '2015-10-31 21:02:24', '', 0, 'http://quotes.academy.red/?p=73', 0, 'post', '', 0),
(75, 1, '2015-10-31 21:03:04', '2015-10-31 21:03:04', 'Debugging is twice as hard as writing the code in the first place. Therefore, if you write the code as cleverly as possible, you are, by definition, not smart enough to debug it.', 'Brian W. Kernighan', '', 'publish', 'open', 'open', '', 'brian-w-kernighan', '', '', '2015-10-31 21:03:04', '2015-10-31 21:03:04', '', 0, 'http://quotes.academy.red/?p=75', 0, 'post', '', 0),
(77, 1, '2015-10-31 21:03:48', '2015-10-31 21:03:48', 'Some people, when confronted with a problem, think "I know, I\'ll use regular expressions." Now they have two problems.', 'Jamie Zawinski', '', 'publish', 'open', 'open', '', 'jamie-zawinski', '', '', '2015-10-31 21:03:48', '2015-10-31 21:03:48', '', 0, 'http://quotes.academy.red/?p=77', 0, 'post', '', 0),
(79, 1, '2015-10-31 21:04:45', '2015-10-31 21:04:45', 'Nine people can\'t make a baby in a month.', 'Fred Brooks', '', 'publish', 'open', 'open', '', 'fred-brooks', '', '', '2015-10-31 21:04:45', '2015-10-31 21:04:45', '', 0, 'http://quotes.academy.red/?p=79', 0, 'post', '', 0),
(81, 1, '2015-10-31 21:05:37', '2015-10-31 21:05:37', 'Computer Science is no more about computers than astronomy is about telescopes.', 'Edsger W. Dijkstra', '', 'publish', 'open', 'open', '', 'edsger-w-dijkstra-3', '', '', '2015-10-31 21:05:37', '2015-10-31 21:05:37', '', 0, 'http://quotes.academy.red/?p=81', 0, 'post', '', 0),
(83, 1, '2015-10-31 21:06:01', '2015-10-31 21:06:01', 'There are only two kinds of languages: the ones people complain about and the ones nobody uses.', 'Bjarne Stroustrup', '', 'publish', 'open', 'open', '', 'bjarne-stroustrup', '', '', '2015-10-31 21:06:01', '2015-10-31 21:06:01', '', 0, 'http://quotes.academy.red/?p=83', 0, 'post', '', 0),
(85, 1, '2015-10-31 21:06:22', '2015-10-31 21:06:22', 'The best thing about a boolean is even if you are wrong, you are only off by a bit.', 'Anonymous', '', 'publish', 'open', 'open', '', 'anonymous', '', '', '2015-10-31 21:06:22', '2015-10-31 21:06:22', '', 0, 'http://quotes.academy.red/?p=85', 0, 'post', '', 0),
(87, 1, '2015-10-31 21:07:06', '2015-10-31 21:07:06', 'Commenting your code is like cleaning your bathroom—you never want to do it, but it really does create a more pleasant experience for you and your guests.', 'Ryan Campbell', '', 'publish', 'open', 'open', '', 'ryan-campbell', '', '', '2015-10-31 21:07:06', '2015-10-31 21:07:06', '', 0, 'http://quotes.academy.red/?p=87', 0, 'post', '', 0),
(89, 1, '2015-10-31 21:07:37', '2015-10-31 21:07:37', 'Java is to JavaScript as car is to carpet.', 'Chris Heilmann', '', 'publish', 'open', 'open', '', 'chris-heilmann', '', '', '2015-10-31 21:07:37', '2015-10-31 21:07:37', '', 0, 'http://quotes.academy.red/?p=89', 0, 'post', '', 0),
(91, 1, '2015-10-31 21:10:27', '2015-10-31 21:10:27', 'A computer is a clock with benefits.', 'Paul Ford', '', 'publish', 'open', 'open', '', 'paul-ford', '', '', '2015-10-31 21:10:27', '2015-10-31 21:10:27', '', 0, 'http://quotes.academy.red/?p=91', 0, 'post', '', 0),
(93, 1, '2015-10-31 21:11:54', '2015-10-31 21:11:54', 'Programming is not a zero-sum game. Teaching something to a fellow programmer doesn\'t take it away from you. I\'m happy to share what I can, because I\'m in it for the love of programming.', 'John Carmack', '', 'publish', 'open', 'open', '', 'john-carmack', '', '', '2015-10-31 21:11:54', '2015-10-31 21:11:54', '', 0, 'http://quotes.academy.red/?p=93', 0, 'post', '', 0),
(95, 1, '2015-10-31 21:13:05', '2015-10-31 21:13:05', 'You might not think that programmers are artists, but programming is an extremely creative profession. It\'s logic-based creativity.', 'John Romero', '', 'publish', 'open', 'open', '', 'john-romero', '', '', '2015-10-31 21:13:05', '2015-10-31 21:13:05', '', 0, 'http://quotes.academy.red/?p=95', 0, 'post', '', 0),
(97, 1, '2015-10-31 21:14:21', '2015-10-31 21:14:21', 'There are two ways to write error-free programs; only the third one works.', 'Alan J. Perlis', '', 'publish', 'open', 'open', '', 'alan-j-perlis-2', '', '', '2015-10-31 21:14:21', '2015-10-31 21:14:21', '', 0, 'http://quotes.academy.red/?p=97', 0, 'post', '', 0),
(101, 1, '2015-11-01 04:35:03', '2015-11-01 04:35:03', 'HTML is the cockroach that will survive a nuclear winter.', 'Jeffery Zeldman', '', 'publish', 'open', 'open', '', 'jeffery-zeldman', '', '', '2015-11-01 04:35:03', '2015-11-01 04:35:03', '', 0, 'http://quotes.academy.red/?p=101', 0, 'post', '', 0),
(103, 1, '2015-11-01 04:35:57', '2015-11-01 04:35:57', 'A typical CMS is like a digestive system with no capacity to poop.', 'Gerry McGovern', '', 'publish', 'open', 'open', '', 'gerry-mcgovern', '', '', '2015-11-01 04:35:57', '2015-11-01 04:35:57', '', 0, 'http://quotes.academy.red/?p=103', 0, 'post', '', 0),
(105, 1, '2015-11-01 04:40:12', '2015-11-01 04:40:12', 'What you make with your code is how you express yourself.', 'Eric Elliott', '', 'publish', 'open', 'open', '', 'eric-elliott', '', '', '2015-11-01 04:40:12', '2015-11-01 04:40:12', '', 0, 'http://quotes.academy.red/?p=105', 0, 'post', '', 0),
(107, 1, '2015-11-01 16:29:23', '2015-11-01 16:29:23', 'Quotes on Dev is a project site for the RED Academy Web Developer Professional program. It\'s used to experiment with Ajax, WP API, jQuery, and other cool things. :)\n\nThis site is heavily inspired by Chris Coyier\'s <a href="http://quotesondesign.com/" target="_blank" rel="noopener">Quotes on Design</a>.', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2015-11-01 16:29:23', '2015-11-01 16:29:23', '', 0, 'http://quotes.academy.red/?page_id=107', 0, 'page', '', 0),
(111, 1, '2015-11-01 16:31:08', '2015-11-01 16:31:08', '', 'Submit a Quote', '', 'publish', 'closed', 'closed', '', 'submit', '', '', '2015-11-01 16:31:08', '2015-11-01 16:31:08', '', 0, 'http://quotes.academy.red/?page_id=111', 0, 'page', '', 0),
(113, 1, '2015-11-01 16:31:48', '2015-11-01 16:31:48', '', 'Archives', '', 'publish', 'closed', 'closed', '', 'archives', '', '', '2015-11-01 16:31:48', '2015-11-01 16:31:48', '', 0, 'http://quotes.academy.red/?page_id=113', 0, 'page', '', 0),
(114, 1, '2018-05-24 03:52:16', '2018-05-24 03:52:16', ' ', '', '', 'publish', 'closed', 'closed', '', '114', '', '', '2018-05-24 03:52:16', '2018-05-24 03:52:16', '', 0, 'http://localhost:8088/quotesondev/2018/05/24/', 1, 'nav_menu_item', '', 0),
(115, 1, '2018-05-24 03:52:16', '2018-05-24 03:52:16', ' ', '', '', 'publish', 'closed', 'closed', '', '115', '', '', '2018-05-24 03:52:16', '2018-05-24 03:52:16', '', 0, 'http://localhost:8088/quotesondev/2018/05/24/', 2, 'nav_menu_item', '', 0),
(116, 1, '2018-05-24 03:52:16', '2018-05-24 03:52:16', ' ', '', '', 'publish', 'closed', 'closed', '', '116', '', '', '2018-05-24 03:52:16', '2018-05-24 03:52:16', '', 0, 'http://localhost:8088/quotesondev/2018/05/24/', 3, 'nav_menu_item', '', 0),
(159, 1, '2017-10-10 21:41:55', '2017-10-10 21:41:55', 'Hardware eventually fails. Software eventually works.', 'Michael Hartung', '', 'publish', 'open', 'open', '', 'michael-hartung', '', '', '2017-10-10 21:41:55', '2017-10-10 21:41:55', '', 0, 'http://quotes.academy.red/?p=159', 0, 'post', '', 0),
(161, 1, '2017-10-10 21:44:10', '2017-10-10 21:44:10', 'The Release Uncertainty Principle says you can accurately know what the software will do, or when you will get it, but not both.', 'Steve Purcell', '', 'publish', 'open', 'open', '', 'steve-purcell', '', '', '2017-10-10 21:44:10', '2017-10-10 21:44:10', '', 0, 'http://quotes.academy.red/?p=161', 0, 'post', '', 0),
(163, 1, '2017-10-10 21:45:46', '2017-10-10 21:45:46', 'The barman asks what the first one wants, two race conditions walk into a bar.', 'I Am Devloper', '', 'publish', 'open', 'open', '', 'i-am-devloper', '', '', '2017-10-10 21:45:46', '2017-10-10 21:45:46', '', 0, 'http://quotes.academy.red/?p=163', 0, 'post', '', 0),
(165, 1, '2017-10-10 21:47:46', '2017-10-10 21:47:46', 'Programmer’s motto: “We’ll cross that bridge when it’s burning underneath us.”', 'Gary Bernhardt', '', 'publish', 'open', 'open', '', 'gary-bernhardt', '', '', '2017-10-10 21:47:46', '2017-10-10 21:47:46', '', 0, 'http://quotes.academy.red/?p=165', 0, 'post', '', 0),
(169, 1, '2017-10-11 12:56:06', '2017-10-11 12:56:06', 'Some programmers, when confronted with a problem, think “I know, I’ll use floating point arithmetic.” Now they have 1.999999999997 problems.', 'Tom Scott', '', 'publish', 'open', 'open', '', 'tom-scott', '', '', '2017-10-11 12:56:06', '2017-10-11 12:56:06', '', 0, 'http://quotes.academy.red/?p=169', 0, 'post', '', 0),
(171, 1, '2017-10-11 12:57:15', '2017-10-11 12:57:15', 'Some people, when confronted with a problem, think “I know, I’ll use multithreading”. Nothhw tpe yawrve o oblems.', 'Erik Osheim', '', 'publish', 'open', 'open', '', 'erik-osheim', '', '', '2017-10-11 12:57:15', '2017-10-11 12:57:15', '', 0, 'http://quotes.academy.red/?p=171', 0, 'post', '', 0),
(173, 1, '2017-10-11 12:58:13', '2017-10-11 12:58:13', 'Some people, when confronted with a problem, think “I know, I’ll use versioning.” Now they have 2.1.0 problems.', 'Jason Coyle', '', 'publish', 'open', 'open', '', 'jason-coyle', '', '', '2017-10-11 12:58:13', '2017-10-11 12:58:13', '', 0, 'http://quotes.academy.red/?p=173', 0, 'post', '', 0),
(175, 1, '2017-10-11 12:58:58', '2017-10-11 12:58:58', 'Some people, when faced with a problem, think, “I know, I’ll use binary.” Now they have 10 problems.', 'Ned Batchelder', '', 'publish', 'open', 'open', '', 'ned-batchelder', '', '', '2017-10-11 12:58:58', '2017-10-11 12:58:58', '', 0, 'http://quotes.academy.red/?p=175', 0, 'post', '', 0),
(177, 1, '2017-10-11 13:06:37', '2017-10-11 13:06:37', 'Debugging is like being the detective in a crime movie where you are also the murderer.', 'Filipe Fortes', '', 'publish', 'open', 'open', '', 'filipe-fortes', '', '', '2017-10-11 13:06:37', '2017-10-11 13:06:37', '', 0, 'http://quotes.academy.red/?p=177', 0, 'post', '', 0),
(179, 1, '2017-10-11 13:26:04', '2017-10-11 13:26:04', 'Unix will give you enough rope to shoot yourself in the foot. If you didn’t think rope would do that, you should have read the man page.', 'Mike Hoye', '', 'publish', 'open', 'open', '', 'mike-hoye', '', '', '2017-10-11 13:26:04', '2017-10-11 13:26:04', '', 0, 'http://quotes.academy.red/?p=179', 0, 'post', '', 0),
(181, 1, '2017-10-11 13:27:11', '2017-10-11 13:27:11', 'When your hammer is C++, everything begins to look like a thumb.', 'Steve Haflich', '', 'publish', 'open', 'open', '', 'steve-haflich', '', '', '2017-10-11 13:27:11', '2017-10-11 13:27:11', '', 0, 'http://quotes.academy.red/?p=181', 0, 'post', '', 0),
(204, 1, '2017-10-11 13:45:57', '2017-10-11 13:45:57', 'Do; or do not. There is no //TODO', 'James Shore', '', 'publish', 'open', 'open', '', 'james-shore', '', '', '2017-10-11 13:45:57', '2017-10-11 13:45:57', '', 0, 'http://quotes.academy.red/?p=204', 0, 'post', '', 0),
(205, 1, '2018-05-25 02:36:27', '2018-05-25 02:36:27', '{"blogdescription":{"value":"Some great quotes about programmers and languages","type":"option","user_id":1,"date_modified_gmt":"2018-05-25 02:26:47"},"site_icon":{"value":207,"type":"option","user_id":1,"date_modified_gmt":"2018-05-25 02:36:27"}}', '', '', 'trash', 'closed', 'closed', '', 'e38cff52-bead-4856-8b82-3977f8856bed', '', '', '2018-05-25 02:36:27', '2018-05-25 02:36:27', '', 0, 'http://localhost:8088/quotesondev/?p=205', 0, 'customize_changeset', '', 0),
(206, 1, '2018-05-25 02:35:46', '2018-05-25 02:35:46', '', 'FavIcon', '', 'inherit', 'open', 'closed', '', 'quot', '', '', '2018-05-25 02:36:06', '2018-05-25 02:36:06', '', 0, 'http://localhost:8088/quotesondev/wp-content/uploads/2018/05/quot.png', 0, 'attachment', 'image/png', 0),
(207, 1, '2018-05-25 02:36:11', '2018-05-25 02:36:11', 'http://localhost:8088/quotesondev/wp-content/uploads/2018/05/cropped-quot.png', 'cropped-quot.png', '', 'inherit', 'open', 'closed', '', 'cropped-quot-png', '', '', '2018-05-25 02:36:11', '2018-05-25 02:36:11', '', 0, 'http://localhost:8088/quotesondev/wp-content/uploads/2018/05/cropped-quot.png', 0, 'attachment', 'image/png', 0),
(208, 1, '2018-05-25 02:37:33', '2018-05-25 02:37:33', '{"show_on_front":{"value":"posts","type":"option","user_id":1,"date_modified_gmt":"2018-05-25 02:36:53"}}', '', '', 'trash', 'closed', 'closed', '', 'a0c2d232-2513-451e-8c62-013256a7293f', '', '', '2018-05-25 02:37:33', '2018-05-25 02:37:33', '', 0, 'http://localhost:8088/quotesondev/?p=208', 0, 'customize_changeset', '', 0),
(209, 1, '2018-05-30 01:25:37', '2018-05-30 01:25:37', '', 'Submit a Quote', '', 'inherit', 'closed', 'closed', '', '111-autosave-v1', '', '', '2018-05-30 01:25:37', '2018-05-30 01:25:37', '', 111, 'http://localhost:8088/quotesondev/2018/05/30/111-autosave-v1/', 0, 'revision', '', 0),
(210, 1, '2018-05-30 01:55:32', '2018-05-30 01:55:32', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost:8088/quotesondev/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-05-30 01:55:32', '2018-05-30 01:55:32', '', 2, 'http://localhost:8088/quotesondev/2018/05/30/2-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2018-05-30 02:44:07', '2018-05-30 02:44:07', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-05-30 02:44:07', '2018-05-30 02:44:07', '', 1, 'http://localhost:8088/quotesondev/2018/05/30/1-revision-v1/', 0, 'revision', '', 0),
(212, 1, '2018-06-01 02:46:52', '2018-06-01 02:46:52', 'Lalala', 'Rafaelsc', '', 'trash', 'closed', 'open', '', 'rafaelsc__trashed', '', '', '2018-06-01 02:47:27', '2018-06-01 02:47:27', '', 0, 'http://localhost:8088/quotesondev/rafaelsc/', 0, 'post', '', 0),
(213, 1, '2018-06-01 02:47:27', '2018-06-01 02:47:27', 'Lalala', 'Rafaelsc', '', 'inherit', 'closed', 'closed', '', '212-revision-v1', '', '', '2018-06-01 02:47:27', '2018-06-01 02:47:27', '', 212, 'http://localhost:8088/quotesondev/212-revision-v1/', 0, 'revision', '', 0),
(214, 1, '2018-06-01 02:47:50', '2018-06-01 02:47:50', 'Thi is the Qoute', 'rafaelsc', '', 'publish', 'closed', 'open', '', 'rafaelsc', '', '', '2018-06-01 02:47:50', '2018-06-01 02:47:50', '', 0, 'http://localhost:8088/quotesondev/rafaelsc/', 0, 'post', '', 0),
(215, 1, '2018-06-01 02:48:37', '2018-06-01 02:48:37', 'ssdsdsd', 'rafaelsc', '', 'publish', 'closed', 'open', '', 'rafaelsc-2', '', '', '2018-06-01 02:48:37', '2018-06-01 02:48:37', '', 0, 'http://localhost:8088/quotesondev/rafaelsc-2/', 0, 'post', '', 0),
(216, 1, '2018-06-01 02:50:25', '2018-06-01 02:50:25', 'akjsakjskas', 'rafaelsc', '', 'publish', 'closed', 'open', '', 'rafaelsc-3', '', '', '2018-06-01 02:50:25', '2018-06-01 02:50:25', '', 0, 'http://localhost:8088/quotesondev/rafaelsc-3/', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(19, 9, 0),
(21, 2, 0),
(21, 16, 0),
(23, 2, 0),
(25, 4, 0),
(25, 6, 0),
(27, 4, 0),
(27, 29, 0),
(29, 2, 0),
(29, 36, 0),
(31, 2, 0),
(33, 1, 0),
(33, 18, 0),
(35, 2, 0),
(37, 1, 0),
(37, 16, 0),
(39, 2, 0),
(39, 16, 0),
(41, 2, 0),
(43, 1, 0),
(43, 22, 0),
(45, 3, 0),
(47, 6, 0),
(47, 17, 0),
(47, 19, 0),
(47, 37, 0),
(49, 6, 0),
(49, 17, 0),
(49, 19, 0),
(49, 37, 0),
(51, 5, 0),
(51, 26, 0),
(51, 27, 0),
(51, 34, 0),
(53, 4, 0),
(53, 30, 0),
(55, 2, 0),
(55, 9, 0),
(57, 2, 0),
(57, 9, 0),
(59, 8, 0),
(61, 3, 0),
(61, 4, 0),
(63, 2, 0),
(65, 8, 0),
(65, 10, 0),
(67, 9, 0),
(67, 41, 0),
(69, 1, 0),
(69, 15, 0),
(71, 8, 0),
(73, 4, 0),
(73, 9, 0),
(73, 10, 0),
(75, 3, 0),
(77, 7, 0),
(77, 32, 0),
(79, 8, 0),
(79, 10, 0),
(79, 31, 0),
(81, 1, 0),
(81, 10, 0),
(81, 16, 0),
(81, 21, 0),
(83, 4, 0),
(83, 5, 0),
(85, 4, 0),
(87, 2, 0),
(87, 14, 0),
(89, 5, 0),
(89, 10, 0),
(89, 24, 0),
(89, 25, 0),
(91, 1, 0),
(91, 10, 0),
(91, 16, 0),
(93, 6, 0),
(93, 19, 0),
(93, 37, 0),
(95, 9, 0),
(95, 17, 0),
(97, 3, 0),
(101, 5, 0),
(101, 23, 0),
(103, 1, 0),
(103, 13, 0),
(105, 9, 0),
(105, 17, 0),
(114, 42, 0),
(115, 42, 0),
(116, 42, 0),
(159, 1, 0),
(159, 21, 0),
(159, 35, 0),
(161, 4, 0),
(161, 35, 0),
(163, 4, 0),
(165, 4, 0),
(169, 7, 0) ;
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(169, 20, 0),
(171, 7, 0),
(171, 38, 0),
(173, 7, 0),
(173, 33, 0),
(175, 7, 0),
(175, 11, 0),
(177, 3, 0),
(179, 4, 0),
(179, 28, 0),
(179, 40, 0),
(181, 5, 0),
(181, 12, 0),
(204, 4, 0),
(204, 14, 0),
(212, 1, 0),
(214, 1, 0),
(215, 1, 0),
(216, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 11),
(2, 2, 'category', '', 0, 11),
(3, 3, 'category', '', 0, 5),
(4, 4, 'category', '', 0, 12),
(5, 5, 'category', '', 0, 5),
(6, 6, 'category', '', 0, 4),
(7, 7, 'category', '', 0, 5),
(8, 8, 'category', '', 0, 4),
(9, 9, 'category', '', 0, 7),
(10, 10, 'post_tag', '', 0, 6),
(11, 11, 'post_tag', '', 0, 1),
(12, 12, 'post_tag', '', 0, 1),
(13, 13, 'post_tag', '', 0, 1),
(14, 14, 'post_tag', '', 0, 2),
(15, 15, 'post_tag', '', 0, 1),
(16, 16, 'post_tag', '', 0, 5),
(17, 17, 'post_tag', '', 0, 4),
(18, 18, 'post_tag', '', 0, 1),
(19, 19, 'post_tag', '', 0, 3),
(20, 20, 'post_tag', '', 0, 1),
(21, 21, 'post_tag', '', 0, 2),
(22, 22, 'post_tag', '', 0, 1),
(23, 23, 'post_tag', '', 0, 1),
(24, 24, 'post_tag', '', 0, 1),
(25, 25, 'post_tag', '', 0, 1),
(26, 26, 'post_tag', '', 0, 1),
(27, 27, 'post_tag', '', 0, 1),
(28, 28, 'post_tag', '', 0, 1),
(29, 29, 'post_tag', '', 0, 1),
(30, 30, 'post_tag', '', 0, 1),
(31, 31, 'post_tag', '', 0, 1),
(32, 32, 'post_tag', '', 0, 1),
(33, 33, 'post_tag', '', 0, 1),
(34, 34, 'post_tag', '', 0, 1),
(35, 35, 'post_tag', '', 0, 2),
(36, 36, 'post_tag', '', 0, 1),
(37, 37, 'post_tag', '', 0, 3),
(38, 38, 'post_tag', '', 0, 1),
(39, 39, 'post_tag', '', 0, 0),
(40, 40, 'post_tag', '', 0, 1),
(41, 41, 'post_tag', '', 0, 1),
(42, 42, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Best Practices', 'best-practices', 0),
(3, 'Debugging', 'debugging', 0),
(4, 'Humour', 'humour', 0),
(5, 'Languages', 'languages', 0),
(6, 'Learning to Code', 'learning-to-code', 0),
(7, 'Now They Have Two Problems', 'two-problems', 0),
(8, 'Productivity', 'productivity', 0),
(9, 'Programming', 'programming', 0),
(10, 'analogies', 'analogies', 0),
(11, 'binary', 'binary', 0),
(12, 'c++', 'c', 0),
(13, 'cms', 'cms', 0),
(14, 'commenting', 'commenting', 0),
(15, 'computer science', 'computer-science', 0),
(16, 'computers', 'computers', 0),
(17, 'creativity', 'creativity', 0),
(18, 'critique', 'critique', 0),
(19, 'education', 'education', 0),
(20, 'floating point', 'floating-point', 0),
(21, 'hardware', 'hardware', 0),
(22, 'history', 'history', 0),
(23, 'html', 'html', 0),
(24, 'java', 'java', 0),
(25, 'javascript', 'javascript', 0),
(26, 'lisp', 'lisp', 0),
(27, 'mvc', 'mvc', 0),
(28, 'operating systems', 'operating-systems', 0),
(29, 'perl', 'perl', 0),
(30, 'plain text', 'plain-text', 0),
(31, 'project management', 'project-management', 0),
(32, 'regular expressions', 'regular-expressions', 0),
(33, 'semver', 'semver', 0),
(34, 'smalltalk', 'smalltalk', 0),
(35, 'software', 'software', 0),
(36, 'specifications', 'specifications', 0),
(37, 'teaching', 'teaching', 0),
(38, 'threading', 'threading', 0),
(39, 'threads', 'threads', 0),
(40, 'unix', 'unix', 0),
(41, 'work', 'work', 0),
(42, 'Main Navigation', 'main-navigation', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse&mfold=o'),
(20, 1, 'wp_user-settings-time', '1527565808'),
(21, 1, 'session_tokens', 'a:1:{s:64:"4a97b743f5f3d86d8b52ba5534f4f9875d11bfca4426a427613c845581cc082c";a:4:{s:10:"expiration";i:1529809540;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36";s:5:"login";i:1529636740;}}'),
(22, 2, 'nickname', 'instructor'),
(23, 2, 'first_name', 'Iris'),
(24, 2, 'last_name', 'Sensei'),
(25, 2, 'description', ''),
(26, 2, 'rich_editing', 'true'),
(27, 2, 'syntax_highlighting', 'true'),
(28, 2, 'comment_shortcuts', 'false'),
(29, 2, 'admin_color', 'fresh'),
(30, 2, 'use_ssl', '0'),
(31, 2, 'show_admin_bar_front', 'true'),
(32, 2, 'locale', ''),
(33, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(34, 2, 'wp_user_level', '10'),
(35, 2, 'dismissed_wp_pointers', 'wp496_privacy') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BUVVf7tBBHFlAs1CDYYbs31fR2EA2F.', 'admin', 'mail@mail.com', '', '2018-05-24 03:34:55', '', 0, 'admin'),
(2, 'instructor', '$P$BXCX8HwWxxJ9hIikT0g7kJti6fo9DK/', 'instructor', 'iris@redacademy.com', '', '2018-06-07 01:05:11', '', 0, 'Iris Sensei') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

